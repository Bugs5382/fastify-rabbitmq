"use strict"
export const DOC_VERSIONS = [
	'stable',
	'v3.0',
];
